#include <stdio.h>

int main(int argc,char *argv[]){
    printf("    *\n");
    printf("   / \\\n");
    printf("  /   \\\n");
    printf(" /-----\\\n");
    printf("/       \\\n");
    return 0;
}