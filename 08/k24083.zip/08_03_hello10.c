#include <stdio.h>

int main(void) {
  int count = 0;

  while (count < 10) {
    printf("Hello, World!\n");
    count += 1;
  }

  return 0;
}
