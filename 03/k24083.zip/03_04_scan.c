#include <stdio.h>

int main(int argc, char *argv[]) {
  int a;
  printf("a? ");
  scanf("%d", &a);
  printf("a = %d\n",a);
  return 0;
}