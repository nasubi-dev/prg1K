#include <stdio.h>

int main(int argc, char *argv[]) {
  int a;
  int b;
  printf("a b? ");
  scanf("%d %d", &a,&b);
  print("%d",a%b);
  return 0;
}