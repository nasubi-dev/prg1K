#include <stdio.h>

int main(int argc,char *argv[]){
  printf("%d + %d = %d\n",2,3,2+3);
    return 0;
}