#include <stdio.h>

int main(int argc, char *argv[]) {
  int a = 5;
  int b =3;
  printf("%d - %d = %d\n",a,b,a-b);
  return 0;
}