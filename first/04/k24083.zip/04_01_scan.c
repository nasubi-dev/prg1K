#include <stdio.h>

int main(int argc, const char* argv[]) {
  int x;

  printf("x? ");
  scanf("%d", &x);
  printf("x = %d\n", x);

  return 0;
}
