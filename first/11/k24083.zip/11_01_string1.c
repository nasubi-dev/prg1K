#include <stdio.h>

int main(void)
{
  char array[] = "abcde";

  printf("文字列: %s\n", array);

  return 0;
}
