extern int b;

int sub(int a)
{
  return (a * b);
};