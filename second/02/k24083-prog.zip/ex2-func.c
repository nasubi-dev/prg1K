#include <stdio.h>
void msg()
{
  printf("こんにちは! お元気ですか?\n");
  printf("ex2-func.c では 違うコメントを定義しました．\n");
}