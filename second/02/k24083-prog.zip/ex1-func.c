#include <stdio.h>
void msg()
{
  printf("ex1-func.c には このコメントが書いてあります．\n\n");
}