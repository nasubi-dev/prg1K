extern void msg(void);
int main()
{
  msg();
  msg();
  msg();
  return 0;
}