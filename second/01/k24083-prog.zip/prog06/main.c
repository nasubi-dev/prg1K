#include <stdio.h>
#define LOOP_COUNT 10

int main(void)
{
  for (int i = 0; i < LOOP_COUNT; i++)
  {
    printf("Hello, world!\n");
  }

  return 0;
}