#include <stdio.h>

int main(int argc, const char* argv[]) {
  for (int i = 0; i < 1000; i++) printf("Hello World\n");

  return 0;
}
