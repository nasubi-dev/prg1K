#include <stdio.h>

#define HELLO "Hello, World!"

int main(void)
{
  printf("%s\n", HELLO);

  return 0;
}